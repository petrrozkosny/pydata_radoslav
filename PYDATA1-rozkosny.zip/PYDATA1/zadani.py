import pandas as pd
df = pd.read_csv('https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv',delimiter=';')
df = df[['DATE','NAME','PRCP','TMAX','TMIN']]
df['ROZDIL_TEPLOT'] = df['TMAX'] - df['TMIN']   
df['DATE'] = pd.to_datetime(df['DATE'])
df['ROK'] = df['DATE'].dt.year

df1 = df.copy()
df1 = df1.loc[df1['NAME']=='RUZYNE']
max_teplota = df1['TMAX'].max()
df1['ROZDIL_OD_MAX_TEPLOTY'] =  max_teplota - df1['TMAX'] 
df1 = df1.set_index('DATE',drop=True)
df1.index.is_unique


df_ruzyne= df.copy()
df_ruzyne = df_ruzyne.loc[df_ruzyne['NAME']=='RUZYNE']
df_ruzyne = df_ruzyne.reset_index(drop=True)
df_ruzyne['ROZDIL_SRAZEK'] = None

for i,r in df_ruzyne.iterrows():
    aktualni_srazky = r['PRCP']
    if i == 0:
        continue
    predchozi_srazky = df_ruzyne.at[i-1,'PRCP']
    df_ruzyne.at[i,'ROZDIL_SRAZEK'] = aktualni_srazky - predchozi_srazky
df_ruzyne.head(10)  


